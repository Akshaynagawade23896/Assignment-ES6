import React from 'react';
import './TodoEmpty.css';

function TodoEmpty() {
  return (
    <div className='emptyTodo'>
      <p>Do not match with given todos</p>
    </div>
  );
}

export { TodoEmpty };
