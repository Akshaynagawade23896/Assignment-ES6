import React from 'react';

function TodoError({ error }) {
  return <p>There is an {error}</p>;
}

export { TodoError };
