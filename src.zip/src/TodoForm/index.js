import React, { useState } from 'react';
import './TodoForm.css';

function TodoForm({ addTodos, setOpenModal }) {
  const [newTodoValue, setNewTodoValue] = useState('');

  const onChange = (event) => {
    setNewTodoValue(event.target.value);
  };

  const onCancel = () => {
    setOpenModal(false);
  };

  const onSubmit = (event) => {
    event.preventDefault();
    addTodos(newTodoValue);
    setOpenModal(false);
  };

  return (
    <form onSubmit={onSubmit}>
      <label>Your New To Do</label>
      <textarea value={newTodoValue} onChange={onChange} placeholder='Enter Text here' />
      <div className='TodoForm-buttonContainer'>
        <button type='button' className='TodoForm-button TodoForm-button-cancel' onClick={onCancel}>
          Cancel
        </button>

        <button className='TodoForm-button TodoForm-button-add' type='submit'>
          Submit
        </button>
      </div>
    </form>
  );
}

export { TodoForm };
