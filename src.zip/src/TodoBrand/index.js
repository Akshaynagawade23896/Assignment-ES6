import React from 'react';
import './TodoBrand.css';

function TodoBrand() {
  return (
    <header className='header'>
      <h1>What are you going to do?</h1>
    </header>
  );
}

export { TodoBrand };
